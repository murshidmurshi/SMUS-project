import React, { useContext, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, TextField, Button } from '@mui/material';
import { AuthContext } from '../../../AuthContext';

// Function to shuffle an array
const shuffleArray = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
};

const timeSlots = ['9 AM - 10 AM', '10 AM - 11 AM', '11 AM - 12 PM', '12 PM - 1 PM', '1 PM - 2 PM', '2 PM - 3 PM', '3 PM - 4 PM'];

const gradientColors = {
  'AI': '#FFA726', // Light orange
  'C++': '#4D86D6', // Light blue
  'Java': '#4CAF50', // Light green
  'ML': '#9C27B0', // Light purple
  'Free': 'black' // Light red
};

const CourseSchedule = ({ selectedProgramme, courses, daysOfWeek, timetableIndex }) => {
  // Generate a shuffled schedule for each day of the week
  const schedules = daysOfWeek.map(() => {
    // Create an array to hold periods for the current day
    const schedule = [];

    // Shuffle the courses array to randomize course order
    const shuffledCourses = shuffleArray(courses);

    // Keep track of credits remaining for each course
    const creditsRemaining = shuffledCourses.reduce((acc, course) => {
      acc[course.subname] = course.credits;
      return acc;
    }, {});

    // Determine the lunch period
    const lunchPeriod = 2; // 3rd period

    // Distribute courses one by one in a round-robin manner for the current day
    // Distribute courses one by one in a round-robin manner for the current day
    let currentPeriod = 0;
    let allCreditsUsed = false;
    while (!allCreditsUsed && currentPeriod < 7) { // <-- Modify this line
      allCreditsUsed = true;

      // Distribute courses with available credits
      shuffledCourses.forEach(course => {
        if (creditsRemaining[course.subname] > 0 && currentPeriod < 6) { // <-- Modify this line
          // Schedule lunch break in the specified period
          if (currentPeriod === lunchPeriod) {
            schedule.push({ subname: "Lunch" });
            currentPeriod++;
          }
          // Schedule the course
          schedule[currentPeriod] = course;
          creditsRemaining[course.subname]--;
          allCreditsUsed = false;
          currentPeriod++; // Move to the next period
        }
      });
    }

    // Fill remaining periods with "Free" if necessary
    while (schedule.length < 7) {
      schedule.push({ subname: "Free" });
    }

    // Shuffle the scheduled subjects again except for lunch break
    const scheduledSubjects = schedule.filter(period => period.subname !== "Lunch");
    const shuffledScheduledSubjects = shuffleArray(scheduledSubjects);
    let subjectIndex = 0;
    for (let i = 0; i < schedule.length; i++) {
      if (schedule[i].subname !== "Lunch") {
        schedule[i] = shuffledScheduledSubjects[subjectIndex++];
      }
    }

    return schedule;
  });

  // Render the schedule
  const allSubjects = courses.map(course => (
    <div key={course.subname}>
      {course.subname}: {course.cre} hours
    </div>
  ));
  return (
    <div>
            <div>
        <h3>All Subjects</h3>
        {allSubjects}
      </div>

      <h2 style={{ padding: '10px' }}>Timetable {timetableIndex + 1} </h2>
      <TableContainer component={Paper}>
        <Table>
          <TableHead style={{ backgroundColor: 'black' }}>
            <TableRow >
              <TableCell style={{ color: 'white', textAlign: 'center' }}>Days</TableCell>
              {timeSlots.map((timeSlot, index) => (
                <TableCell key={index} style={{ color: 'white', textAlign: 'center', margin: 15 }}>{timeSlot}</TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {daysOfWeek.map((day, dayIndex) => (
              <TableRow key={dayIndex}>
                <TableCell style={{ backgroundColor: 'black', color: 'white', textAlign: 'center' }}>{day}</TableCell>
                {schedules[dayIndex].map((scheduleItem, periodIndex) => (
                  <TableCell
                    key={periodIndex}
                    style={{
                      background: scheduleItem.subname === "Lunch" ? "green" :
                        scheduleItem.subname === "Free" ? "#beb9b9" :
                          gradientColors[scheduleItem.subname],
                      color: scheduleItem.subname === "Lunch" ? 'white' :
                        scheduleItem.subname === "Free" ? 'black' :
                          'black',
                      padding: '8px',
                      margin: '5px',
                      textAlign: 'center'
                    }}
                  >
                    <div>
                      {scheduleItem.subname !== "Free" && scheduleItem.subname !== "Lunch" && (
                        <>
                          <div>{scheduleItem.Class}</div>
                          <div> {scheduleItem.teacher}</div>
                        </>
                      )}
                      <div>{scheduleItem.subname}</div>
                    </div>
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

const App = () => {
  const [timetableLength, setTimetableLength] = useState(1); // Default timetable length
  const [generatedTimetables, setGeneratedTimetables] = useState([]);
  const { selectedProgramme } = useContext(AuthContext)

  // const selectedProgramme = "BCA";
  // const courses = [
  //   { subname: 'AI', credits: 1, teacher: 'Smitha', Class: "LH1" },
  //   { subname: 'C++', credits: 1, teacher: 'Rajesh', Class: "LH2" },
  //   { subname: 'Java', credits: 1, teacher: 'Smitha', Class: "LH3" },
  //   { subname: 'ML', credits: 1, teacher: 'Rahul', Class: "LH4" }
  // ];
  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  const generateTimetables = () => {
    const timetables = [];
    for (let i = 0; i < timetableLength; i++) {
      const timetable = (
        <CourseSchedule key={i} selectedProgramme={selectedProgramme} courses={selectedProgramme?.courses} daysOfWeek={daysOfWeek} timetableIndex={i} />
      );
      timetables.push(timetable);
    }
    setGeneratedTimetables(timetables);
  };

  const shuffleTimetable = () => {
    const shuffledTimetables = generatedTimetables.map(timetable => (
      <CourseSchedule key={Math.random()} selectedProgramme={selectedProgramme} courses={selectedProgramme?.courses} daysOfWeek={daysOfWeek} />
    ));
    setGeneratedTimetables(shuffledTimetables);
  };

  return (
    <>
    <p></p>
    <div>
      <TextField
        label="Number of Timetables"
        variant="outlined"
        type="number"
        value={timetableLength}
        onChange={(e) => setTimetableLength(parseInt(e.target.value))}
      />
      <Button variant="contained" color="primary" style={{ marginLeft: '10px' }} onClick={generateTimetables}>Generate Timetables</Button>
      <Button variant="contained" color="secondary" style={{ marginLeft: '10px' }} onClick={shuffleTimetable}>Shuffle Timetable</Button>
      {generatedTimetables}
    </div>
    
    </>
  );
};

export default App;
